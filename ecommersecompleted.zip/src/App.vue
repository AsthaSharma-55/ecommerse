<script setup>

</script>

<template>
 
<router-view></router-view>

<main>

</main>
</template>

<style scoped>

</style>
