<template>
  <h1>About page</h1>
</template>

<script>
export default {
    name:"About"

}
</script>

<style>

</style>